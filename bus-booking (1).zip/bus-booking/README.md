# Nightline — Intelligent Bus Ticket Booking System

A full-stack bus ticket booking demo with a smart ranking/pricing engine, a REST API, a SQLite database, and a dependency-free HTML/CSS/JS frontend.

**Live pieces:**
- `frontend/` — plain HTML + CSS + JS single-page app (no build step, no framework required)
- `backend/` — Node.js + Express REST API
- Database — SQLite, auto-created and auto-seeded on first run (`backend/bus_booking.db`)

## Design

A custom night-transit visual identity, not a default template: deep navy background with an amber "headlight" accent, `Space Grotesk` for display type, `Inter` for body copy, and `JetBrains Mono` for tickets/seat numbers/prices. The signature touch is the animated dashed "route ribbon" in the hero. Small details carry the polish — a perforated ticket stub, a shimmering skeleton loader while searching, toast notifications instead of browser alerts, hover-lift on result cards, and a front-of-bus indicator on the seat map.

## What makes it "intelligent"

- **Dynamic pricing** — fares rise as a trip fills up (`backend/intelligence.js → dynamicPrice`), the same way real transport pricing works, with an early-bird discount on nearly-empty trips.
- **Smart ranking** — search results are ranked by a blended score of price, trip duration, seat availability and operator rating, not just departure time (`rankTrips`).
- **Badges** — trips are auto-tagged as *Smart Pick*, *Cheapest*, *Fastest*, or *Filling Fast*.
- **Fuzzy city matching** — "chennai", "Chennai ", "CHEN" all resolve to the same city (`cityMatches`).
- **Seat recommendations** — the seat map highlights window seats first when suggesting where to sit (`recommendSeats`).

## Project structure

```
bus-booking/
├── backend/
│   ├── server.js        # Express app + all REST routes
│   ├── db.js             # SQLite connection, auto-init on first run
│   ├── schema.sql        # Table definitions
│   ├── seed.js            # Demo operators/buses/trips/seats generator
│   ├── intelligence.js   # Pricing, ranking, city-matching, seat recommendation logic
│   └── package.json
├── frontend/
│   ├── index.html
│   ├── style.css
│   └── app.js
├── .gitignore
└── README.md
```

## Getting started locally

### Prerequisites
- [Node.js](https://nodejs.org) 18 or later

### 1. Run the backend

```bash
cd backend
npm install
npm start
```

This starts the API at `http://localhost:4000`. On the very first run it will:
1. Create `bus_booking.db` (SQLite file, ignored by git)
2. Build the schema from `schema.sql`
3. Seed it with demo operators, buses, and a week of trips across a handful of routes (Coimbatore, Chennai, Bengaluru, Hyderabad, Madurai) with randomised seat occupancy, so dynamic pricing has real data to react to.

To reset the data, just delete `backend/bus_booking.db*` and restart the server.

### 2. Run the frontend

The frontend is static — no bundler needed. Easiest options:

```bash
cd frontend
npx serve .
# or simply open index.html directly in a browser
```

If your backend isn't on `http://localhost:4000`, set `window.API_BASE` before `app.js` loads, e.g. add this line in `index.html` above the `<script src="app.js">` tag:

```html
<script>window.API_BASE = "https://your-deployed-backend.example.com/api";</script>
```

## API reference

| Method | Endpoint | Description |
|---|---|---|
| GET | `/api/health` | Health check |
| GET | `/api/cities` | Distinct list of served cities (for autocomplete) |
| GET | `/api/trips/search?source=&destination=&date=` | Ranked, priced, badge-tagged search results |
| GET | `/api/trips/:id` | Single trip detail with live pricing |
| GET | `/api/trips/:id/seats` | Seat map with recommended seats flagged |
| POST | `/api/bookings` | Create a booking `{ tripId, seatIds, passengerName, passengerAge, passengerGender, phone, email }` |
| GET | `/api/bookings/:pnr` | Look up a booking / e-ticket by PNR |
| DELETE | `/api/bookings/:pnr` | Cancel a booking and release its seats |

## Uploading this project to GitHub

1. Create a new, empty repository on GitHub (don't initialize it with a README — you already have one here).
2. From inside this project folder, run:

```bash
git init
git add .
git commit -m "Initial commit: Nightline intelligent bus booking system"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo-name>.git
git push -u origin main
```

3. Replace `<your-username>/<your-repo-name>` with your actual GitHub repo path. If prompted for credentials, use a [personal access token](https://github.com/settings/tokens) instead of your password.

### Deploying it for real

- **Backend**: Render, Railway, Fly.io, or a small VPS all work well for a Node + SQLite app. Just make sure the disk persists between deploys (SQLite is a file).
- **Frontend**: GitHub Pages, Netlify, or Vercel can host the static `frontend/` folder directly — just set `window.API_BASE` to your deployed backend URL as shown above.

## Notes and limitations

This is a learning/demo project: there's no authentication, no real payment processing, and booking concurrency is handled with a simple "already booked" check rather than row-level locking. It's a solid base to extend with user accounts, payment gateway integration, and a production database (Postgres/MySQL) if you want to take it further.

## License

MIT — do whatever you like with it.
