-- Intelligent Bus Ticket Booking System - Database Schema
-- SQLite

DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS seats;
DROP TABLE IF EXISTS trips;
DROP TABLE IF EXISTS buses;
DROP TABLE IF EXISTS operators;

CREATE TABLE operators (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  rating REAL DEFAULT 4.0
);

CREATE TABLE buses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  operator_id INTEGER NOT NULL,
  bus_number TEXT NOT NULL,
  bus_type TEXT NOT NULL,           -- e.g. "AC Sleeper", "Non-AC Seater"
  total_seats INTEGER NOT NULL,
  amenities TEXT,                   -- comma separated: "WiFi,Charging,Blanket"
  FOREIGN KEY (operator_id) REFERENCES operators(id)
);

CREATE TABLE trips (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  bus_id INTEGER NOT NULL,
  source TEXT NOT NULL,
  destination TEXT NOT NULL,
  travel_date TEXT NOT NULL,        -- YYYY-MM-DD
  departure_time TEXT NOT NULL,     -- HH:MM
  arrival_time TEXT NOT NULL,       -- HH:MM
  duration_minutes INTEGER NOT NULL,
  base_price REAL NOT NULL,
  FOREIGN KEY (bus_id) REFERENCES buses(id)
);

CREATE TABLE seats (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  trip_id INTEGER NOT NULL,
  seat_number TEXT NOT NULL,        -- e.g. "U1", "L4"
  seat_type TEXT NOT NULL,          -- "window" | "aisle" | "middle"
  deck TEXT NOT NULL DEFAULT 'lower',-- "lower" | "upper"
  is_booked INTEGER NOT NULL DEFAULT 0,
  FOREIGN KEY (trip_id) REFERENCES trips(id)
);

CREATE TABLE bookings (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  pnr TEXT UNIQUE NOT NULL,
  trip_id INTEGER NOT NULL,
  seat_ids TEXT NOT NULL,           -- JSON array of seat ids
  passenger_name TEXT NOT NULL,
  passenger_age INTEGER,
  passenger_gender TEXT,
  phone TEXT NOT NULL,
  email TEXT,
  price_paid REAL NOT NULL,
  status TEXT NOT NULL DEFAULT 'CONFIRMED', -- CONFIRMED | CANCELLED
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  FOREIGN KEY (trip_id) REFERENCES trips(id)
);

CREATE INDEX idx_trips_route ON trips(source, destination, travel_date);
CREATE INDEX idx_seats_trip ON seats(trip_id);
CREATE INDEX idx_bookings_trip ON bookings(trip_id);
