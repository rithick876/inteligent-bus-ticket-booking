const path = require('path');
const fs = require('fs');
const Database = require('better-sqlite3');

const DB_PATH = path.join(__dirname, 'bus_booking.db');
const isNewDb = !fs.existsSync(DB_PATH);

const db = new Database(DB_PATH);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

function initSchema() {
  const schema = fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8');
  db.exec(schema);
}

// Always rebuild schema on fresh DB, then seed with demo data.
if (isNewDb) {
  initSchema();
  require('./seed')(db);
  console.log('Database created and seeded at', DB_PATH);
}

module.exports = db;
