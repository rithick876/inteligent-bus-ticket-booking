// "Intelligent" layer of the booking system.
// Pure functions only -- no DB access here, easy to unit test.

/**
 * Demand-based dynamic pricing.
 * The fewer seats left, the higher the multiplier -- similar to how real
 * bus/airline fares surge as a trip fills up. Capped so it never runs away.
 */
function dynamicPrice(basePrice, totalSeats, availableSeats) {
  const occupancy = 1 - availableSeats / totalSeats; // 0 (empty) -> 1 (full)
  let multiplier = 1;

  if (occupancy >= 0.9) multiplier = 1.35;
  else if (occupancy >= 0.75) multiplier = 1.22;
  else if (occupancy >= 0.5) multiplier = 1.1;
  else if (occupancy >= 0.25) multiplier = 1.02;
  else multiplier = 0.95; // early-bird discount when a trip is nearly empty

  const price = Math.round(basePrice * multiplier);
  return { price, occupancy: Math.round(occupancy * 100) };
}

/**
 * Ranks trips by a blended "smart score" so the best options bubble to the
 * top instead of just sorting by departure time. Cheaper, faster and less
 * crowded trips score higher; the caller can still re-sort by a single
 * dimension (price/duration) if the user picks a filter.
 */
function rankTrips(trips) {
  if (trips.length === 0) return trips;

  const prices = trips.map(t => t.currentPrice);
  const durations = trips.map(t => t.duration_minutes);
  const minPrice = Math.min(...prices);
  const maxPrice = Math.max(...prices);
  const minDur = Math.min(...durations);
  const maxDur = Math.max(...durations);

  const norm = (v, min, max) => (max === min ? 0 : (v - min) / (max - min));

  return trips
    .map(trip => {
      const priceScore = 1 - norm(trip.currentPrice, minPrice, maxPrice); // cheaper = better
      const durationScore = 1 - norm(trip.duration_minutes, minDur, maxDur); // faster = better
      const availabilityScore = trip.availableSeats / trip.totalSeats; // more room = better
      const ratingScore = (trip.operatorRating || 4) / 5;

      const smartScore =
        priceScore * 0.35 + durationScore * 0.25 + availabilityScore * 0.15 + ratingScore * 0.25;

      return { ...trip, smartScore: Math.round(smartScore * 100) };
    })
    .sort((a, b) => b.smartScore - a.smartScore);
}

/** Tags a ranked list with helpful badges: cheapest, fastest, top pick. */
function tagBadges(trips) {
  if (trips.length === 0) return trips;
  const cheapestId = trips.reduce((a, b) => (b.currentPrice < a.currentPrice ? b : a)).id;
  const fastestId = trips.reduce((a, b) => (b.duration_minutes < a.duration_minutes ? b : a)).id;
  const topPickId = trips[0].id; // already sorted by smartScore desc

  return trips.map(trip => {
    const badges = [];
    if (trip.id === topPickId) badges.push('Smart Pick');
    if (trip.id === cheapestId) badges.push('Cheapest');
    if (trip.id === fastestId) badges.push('Fastest');
    if (trip.availableSeats <= 5 && trip.availableSeats > 0) badges.push('Filling Fast');
    return { ...trip, badges };
  });
}

/**
 * Fuzzy-ish city matching: case/whitespace insensitive, substring match,
 * so "chennai", "Chennai ", "CHEN" all resolve sensibly.
 */
function normalizeCity(city) {
  return (city || '').trim().toLowerCase();
}

function cityMatches(candidate, query) {
  const c = normalizeCity(candidate);
  const q = normalizeCity(query);
  if (!q) return true;
  return c.includes(q) || q.includes(c);
}

/** Suggests window seats first, then aisle, favouring seats not next to a stranger. */
function recommendSeats(seats, count) {
  const available = seats.filter(s => !s.is_booked);
  const preference = { window: 0, aisle: 1, middle: 2 };
  return [...available]
    .sort((a, b) => (preference[a.seat_type] ?? 3) - (preference[b.seat_type] ?? 3))
    .slice(0, count);
}

module.exports = {
  dynamicPrice,
  rankTrips,
  tagBadges,
  cityMatches,
  normalizeCity,
  recommendSeats,
};
