const express = require('express');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');
const db = require('./db');
const { dynamicPrice, rankTrips, tagBadges, cityMatches, recommendSeats } = require('./intelligence');

const app = express();
const PORT = process.env.PORT || 4000;

app.use(cors());
app.use(express.json());

// ---------- Helpers ----------

function getTripWithPricing(trip) {
  const seatStats = db
    .prepare('SELECT COUNT(*) AS total, SUM(is_booked) AS booked FROM seats WHERE trip_id = ?')
    .get(trip.id);
  const totalSeats = seatStats.total;
  const bookedSeats = seatStats.booked || 0;
  const availableSeats = totalSeats - bookedSeats;
  const { price, occupancy } = dynamicPrice(trip.base_price, totalSeats, availableSeats);

  return {
    ...trip,
    totalSeats,
    availableSeats,
    occupancyPercent: occupancy,
    currentPrice: price,
  };
}

function generatePNR() {
  return uuidv4().replace(/-/g, '').slice(0, 8).toUpperCase();
}

// ---------- Routes ----------

app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Distinct list of cities served, for autocomplete on the frontend.
app.get('/api/cities', (req, res) => {
  const rows = db.prepare('SELECT DISTINCT source AS city FROM trips UNION SELECT DISTINCT destination AS city FROM trips').all();
  const cities = [...new Set(rows.map(r => r.city))].sort();
  res.json(cities);
});

// Smart search: source, destination, date (all optional -> broad search).
app.get('/api/trips/search', (req, res) => {
  const { source = '', destination = '', date = '' } = req.query;

  let rows = db
    .prepare(
      `SELECT trips.*, buses.bus_number, buses.bus_type, buses.amenities, buses.total_seats AS bus_total_seats,
              operators.name AS operator_name, operators.rating AS operator_rating
       FROM trips
       JOIN buses ON buses.id = trips.bus_id
       JOIN operators ON operators.id = buses.operator_id
       WHERE (? = '' OR trips.travel_date = ?)`
    )
    .all(date, date);

  // Fuzzy city filtering happens in JS so we can be lenient with partial matches.
  rows = rows.filter(t => cityMatches(t.source, source) && cityMatches(t.destination, destination));

  let trips = rows.map(trip => {
    const priced = getTripWithPricing(trip);
    return { ...priced, operatorRating: trip.operator_rating };
  });

  trips = rankTrips(trips);
  trips = tagBadges(trips);

  res.json({ count: trips.length, trips });
});

// Single trip detail.
app.get('/api/trips/:id', (req, res) => {
  const trip = db
    .prepare(
      `SELECT trips.*, buses.bus_number, buses.bus_type, buses.amenities, buses.total_seats AS bus_total_seats,
              operators.name AS operator_name, operators.rating AS operator_rating
       FROM trips
       JOIN buses ON buses.id = trips.bus_id
       JOIN operators ON operators.id = buses.operator_id
       WHERE trips.id = ?`
    )
    .get(req.params.id);

  if (!trip) return res.status(404).json({ error: 'Trip not found' });
  res.json(getTripWithPricing(trip));
});

// Seat map for a trip, with a short list of "recommended" seat ids.
app.get('/api/trips/:id/seats', (req, res) => {
  const seats = db.prepare('SELECT * FROM seats WHERE trip_id = ? ORDER BY deck, seat_number').all(req.params.id);
  if (seats.length === 0) return res.status(404).json({ error: 'Trip not found' });

  const recommended = recommendSeats(seats, 3).map(s => s.id);
  res.json({
    seats: seats.map(s => ({ ...s, is_booked: !!s.is_booked, recommended: recommended.includes(s.id) })),
  });
});

// Create a booking for one or more seats on a trip.
app.post('/api/bookings', (req, res) => {
  const { tripId, seatIds, passengerName, passengerAge, passengerGender, phone, email } = req.body;

  if (!tripId || !Array.isArray(seatIds) || seatIds.length === 0 || !passengerName || !phone) {
    return res.status(400).json({ error: 'tripId, seatIds, passengerName and phone are required' });
  }

  const trip = db.prepare('SELECT * FROM trips WHERE id = ?').get(tripId);
  if (!trip) return res.status(404).json({ error: 'Trip not found' });

  const placeholders = seatIds.map(() => '?').join(',');
  const seats = db
    .prepare(`SELECT * FROM seats WHERE id IN (${placeholders}) AND trip_id = ?`)
    .all(...seatIds, tripId);

  if (seats.length !== seatIds.length) {
    return res.status(400).json({ error: 'One or more seats are invalid for this trip' });
  }
  const alreadyBooked = seats.filter(s => s.is_booked);
  if (alreadyBooked.length > 0) {
    return res.status(409).json({
      error: 'Some selected seats were just booked by someone else',
      seatNumbers: alreadyBooked.map(s => s.seat_number),
    });
  }

  const priced = getTripWithPricing(trip);
  const totalPrice = priced.currentPrice * seatIds.length;
  const pnr = generatePNR();

  const transaction = db.transaction(() => {
    const updateSeat = db.prepare('UPDATE seats SET is_booked = 1 WHERE id = ?');
    seatIds.forEach(id => updateSeat.run(id));

    db.prepare(
      `INSERT INTO bookings (pnr, trip_id, seat_ids, passenger_name, passenger_age, passenger_gender, phone, email, price_paid)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).run(
      pnr,
      tripId,
      JSON.stringify(seatIds),
      passengerName,
      passengerAge || null,
      passengerGender || null,
      phone,
      email || null,
      totalPrice
    );
  });

  transaction();

  res.status(201).json({
    pnr,
    tripId,
    seatNumbers: seats.map(s => s.seat_number),
    totalPrice,
    status: 'CONFIRMED',
  });
});

// Look up a booking by PNR (also used as a virtual "e-ticket").
app.get('/api/bookings/:pnr', (req, res) => {
  const booking = db.prepare('SELECT * FROM bookings WHERE pnr = ?').get(req.params.pnr);
  if (!booking) return res.status(404).json({ error: 'Booking not found' });

  const trip = db
    .prepare(
      `SELECT trips.*, buses.bus_number, buses.bus_type, operators.name AS operator_name
       FROM trips JOIN buses ON buses.id = trips.bus_id JOIN operators ON operators.id = buses.operator_id
       WHERE trips.id = ?`
    )
    .get(booking.trip_id);

  const seatIds = JSON.parse(booking.seat_ids);
  const placeholders = seatIds.map(() => '?').join(',');
  const seats = db.prepare(`SELECT seat_number FROM seats WHERE id IN (${placeholders})`).all(...seatIds);

  res.json({ ...booking, trip, seatNumbers: seats.map(s => s.seat_number) });
});

// Cancel a booking and release its seats.
app.delete('/api/bookings/:pnr', (req, res) => {
  const booking = db.prepare('SELECT * FROM bookings WHERE pnr = ?').get(req.params.pnr);
  if (!booking) return res.status(404).json({ error: 'Booking not found' });
  if (booking.status === 'CANCELLED') return res.status(400).json({ error: 'Booking already cancelled' });

  const seatIds = JSON.parse(booking.seat_ids);
  const placeholders = seatIds.map(() => '?').join(',');

  const transaction = db.transaction(() => {
    db.prepare(`UPDATE seats SET is_booked = 0 WHERE id IN (${placeholders})`).run(...seatIds);
    db.prepare('UPDATE bookings SET status = ? WHERE pnr = ?').run('CANCELLED', req.params.pnr);
  });
  transaction();

  res.json({ pnr: req.params.pnr, status: 'CANCELLED' });
});

app.listen(PORT, () => {
  console.log(`Bus booking API running at http://localhost:${PORT}`);
});
