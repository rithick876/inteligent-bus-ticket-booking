// Seeds the database with demo operators, buses, trips and seats.
// Exported as a function so db.js can call it once, right after schema creation.

const OPERATORS = [
  { name: 'Skyline Travels', rating: 4.5 },
  { name: 'National Express', rating: 4.1 },
  { name: 'Comfort Cruiser', rating: 4.7 },
  { name: 'City Link', rating: 3.9 },
];

const ROUTES = [
  { source: 'Coimbatore', destination: 'Chennai', duration: 480, base: 650 },
  { source: 'Coimbatore', destination: 'Bengaluru', duration: 360, base: 550 },
  { source: 'Chennai', destination: 'Bengaluru', duration: 390, base: 600 },
  { source: 'Bengaluru', destination: 'Hyderabad', duration: 540, base: 800 },
  { source: 'Chennai', destination: 'Madurai', duration: 420, base: 500 },
];

const BUS_TYPES = [
  { type: 'AC Sleeper', amenities: 'WiFi,Charging,Blanket,Water Bottle', seats: 30 },
  { type: 'AC Seater', amenities: 'WiFi,Charging', seats: 40 },
  { type: 'Non-AC Seater', amenities: 'Charging', seats: 45 },
  { type: 'AC Semi-Sleeper', amenities: 'WiFi,Charging,Blanket', seats: 36 },
];

const DEPARTURES = ['06:00', '09:30', '13:00', '18:30', '22:00', '23:30'];

function pad(n) { return n < 10 ? '0' + n : '' + n; }

function addMinutes(time, minutes) {
  const [h, m] = time.split(':').map(Number);
  const total = h * 60 + m + minutes;
  const dayMinutes = ((total % 1440) + 1440) % 1440;
  return `${pad(Math.floor(dayMinutes / 60))}:${pad(dayMinutes % 60)}`;
}

function todayPlus(days) {
  const d = new Date();
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

function seatLayoutFor(totalSeats, busType) {
  // Sleeper buses: single seats labeled U (upper) / L (lower)
  // Seater buses: 2+2 layout, window/aisle/middle by column position
  const seats = [];
  if (busType.includes('Sleeper')) {
    const half = Math.floor(totalSeats / 2);
    for (let i = 1; i <= half; i++) {
      seats.push({ seat_number: `L${i}`, seat_type: i % 2 === 0 ? 'aisle' : 'window', deck: 'lower' });
      seats.push({ seat_number: `U${i}`, seat_type: i % 2 === 0 ? 'aisle' : 'window', deck: 'upper' });
    }
  } else {
    // 2+2 seater: columns A,B (window,aisle) | C,D (aisle,window)
    const rows = Math.ceil(totalSeats / 4);
    const cols = [
      { label: 'A', type: 'window' },
      { label: 'B', type: 'aisle' },
      { label: 'C', type: 'aisle' },
      { label: 'D', type: 'window' },
    ];
    let count = 0;
    for (let r = 1; r <= rows; r++) {
      for (const c of cols) {
        if (count >= totalSeats) break;
        seats.push({ seat_number: `${r}${c.label}`, seat_type: c.type, deck: 'lower' });
        count++;
      }
    }
  }
  return seats;
}

module.exports = function seed(db) {
  const insertOperator = db.prepare('INSERT INTO operators (name, rating) VALUES (?, ?)');
  const operatorIds = OPERATORS.map(op => insertOperator.run(op.name, op.rating).lastInsertRowid);

  const insertBus = db.prepare(
    'INSERT INTO buses (operator_id, bus_number, bus_type, total_seats, amenities) VALUES (?, ?, ?, ?, ?)'
  );
  const insertTrip = db.prepare(
    `INSERT INTO trips (bus_id, source, destination, travel_date, departure_time, arrival_time, duration_minutes, base_price)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?)`
  );
  const insertSeat = db.prepare(
    'INSERT INTO seats (trip_id, seat_number, seat_type, deck, is_booked) VALUES (?, ?, ?, ?, ?)'
  );

  let busCounter = 1000;
  const days = [0, 1, 2, 3, 4, 5, 6]; // seed a week of trips

  for (const route of ROUTES) {
    for (const dayOffset of days) {
      // 2-3 buses per route per day, different operators/types/times
      const tripsToday = 2 + (dayOffset % 2);
      for (let t = 0; t < tripsToday; t++) {
        const busType = BUS_TYPES[(t + dayOffset) % BUS_TYPES.length];
        const operatorId = operatorIds[(t + dayOffset) % operatorIds.length];
        busCounter++;
        const busId = insertBus.run(
          operatorId,
          `BUS-${busCounter}`,
          busType.type,
          busType.seats,
          busType.amenities
        ).lastInsertRowid;

        const departure = DEPARTURES[(t + dayOffset) % DEPARTURES.length];
        const arrival = addMinutes(departure, route.duration);
        const priceJitter = 1 + ((t + dayOffset) % 3) * 0.08; // slight fare variation
        const price = Math.round(route.base * priceJitter);

        const tripId = insertTrip.run(
          busId,
          route.source,
          route.destination,
          todayPlus(dayOffset),
          departure,
          arrival,
          route.duration,
          price
        ).lastInsertRowid;

        const seats = seatLayoutFor(busType.seats, busType.type);
        // Randomly pre-book a portion of seats so occupancy/dynamic pricing has real data
        const occupancy = 0.15 + Math.random() * 0.55;
        seats.forEach(seat => {
          const isBooked = Math.random() < occupancy ? 1 : 0;
          insertSeat.run(tripId, seat.seat_number, seat.seat_type, seat.deck, isBooked);
        });
      }
    }
  }
};
