// Point this at your deployed backend if not running both on localhost.
const API_BASE = window.API_BASE || 'http://localhost:4000/api';

const state = {
  trips: [],
  sortBy: 'smart',
  currentTrip: null,
  selectedSeatIds: [],
  seats: [],
};

const $ = sel => document.querySelector(sel);

function toast(message, type = 'info') {
  const stack = $('#toastStack');
  const el = document.createElement('div');
  el.className = `toast${type === 'error' ? ' error' : ''}`;
  el.textContent = message;
  stack.appendChild(el);
  setTimeout(() => el.remove(), 4000);
}

// ---------- Init ----------

document.addEventListener('DOMContentLoaded', () => {
  loadCities();
  $('#date').valueAsDate = new Date();
  $('#searchForm').addEventListener('submit', onSearchSubmit);
  $('#swapBtn').addEventListener('click', swapCities);
  document.querySelectorAll('.chip').forEach(chip => chip.addEventListener('click', onSortChip));
  $('#closeSeatModal').addEventListener('click', () => $('#seatModal').close());
  $('#closeTicketModal').addEventListener('click', () => $('#ticketModal').close());
  $('#passengerForm').addEventListener('submit', onConfirmBooking);
  $('#myTicketBtn').addEventListener('click', onLookupTicket);
});

async function loadCities() {
  try {
    const res = await fetch(`${API_BASE}/cities`);
    const cities = await res.json();
    const list = $('#cityList');
    list.innerHTML = cities.map(c => `<option value="${c}"></option>`).join('');
  } catch (err) {
    console.error('Could not load cities', err);
  }
}

function swapCities() {
  const a = $('#source').value;
  $('#source').value = $('#destination').value;
  $('#destination').value = a;
}

// ---------- Search ----------

async function onSearchSubmit(e) {
  e.preventDefault();
  const source = $('#source').value.trim();
  const destination = $('#destination').value.trim();
  const date = $('#date').value;

  $('#resultsHeader').hidden = true;
  $('#emptyState').hidden = true;
  $('#resultsList').innerHTML = Array.from({ length: 3 }, () => '<div class="skeleton-card"></div>').join('');

  try {
    const params = new URLSearchParams({ source, destination, date });
    const res = await fetch(`${API_BASE}/trips/search?${params.toString()}`);
    const data = await res.json();
    state.trips = data.trips || [];
    state.sortBy = 'smart';
    document.querySelectorAll('.chip').forEach(c => c.classList.toggle('active', c.dataset.sort === 'smart'));

    $('#resultsTitle').textContent = `${source || 'Anywhere'} → ${destination || 'Anywhere'} · ${data.count} trip${data.count === 1 ? '' : 's'} found`;
    $('#resultsHeader').hidden = false;
    renderResults();
  } catch (err) {
    console.error(err);
    $('#resultsList').innerHTML = '';
    $('#emptyState').hidden = false;
    $('#emptyState').textContent = 'Could not reach the booking server. Is the backend running?';
  }
}

function onSortChip(e) {
  const sort = e.currentTarget.dataset.sort;
  state.sortBy = sort;
  document.querySelectorAll('.chip').forEach(c => c.classList.toggle('active', c === e.currentTarget));
  renderResults();
}

function sortedTrips() {
  const trips = [...state.trips];
  if (state.sortBy === 'price') return trips.sort((a, b) => a.currentPrice - b.currentPrice);
  if (state.sortBy === 'duration') return trips.sort((a, b) => a.duration_minutes - b.duration_minutes);
  return trips.sort((a, b) => b.smartScore - a.smartScore); // smart (default, server order)
}

function renderResults() {
  const list = $('#resultsList');
  const trips = sortedTrips();

  if (trips.length === 0) {
    list.innerHTML = '';
    $('#emptyState').hidden = false;
    $('#emptyState').textContent = 'No buses found for that route yet — try nearby dates or check the city spelling.';
    return;
  }
  $('#emptyState').hidden = true;

  list.innerHTML = trips.map(tripCardHtml).join('');

  trips.forEach(trip => {
    const btn = document.getElementById(`select-${trip.id}`);
    if (btn) btn.addEventListener('click', () => openSeatModal(trip));
  });
}

function badgeClass(label) {
  if (label === 'Smart Pick') return 'smart';
  if (label === 'Cheapest') return 'cheap';
  if (label === 'Fastest') return 'fast';
  return 'filling';
}

function formatDuration(minutes) {
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return `${h}h ${m ? m + 'm' : ''}`.trim();
}

function tripCardHtml(trip) {
  const badges = (trip.badges || []).map(b => `<span class="badge ${badgeClass(b)}">${b}</span>`).join('');
  return `
    <article class="trip-card">
      <div>
        <div class="trip-top">
          <div>
            <div class="trip-operator">${trip.operator_name}</div>
            <div class="trip-type">${trip.bus_type} · ${trip.bus_number}</div>
          </div>
          <div class="badges">${badges}</div>
        </div>

        <div class="trip-route">
          <div>
            <div class="trip-time">${trip.departure_time}</div>
            <div class="trip-city">${trip.source}</div>
          </div>
          <div class="line"><span class="duration">${formatDuration(trip.duration_minutes)}</span></div>
          <div>
            <div class="trip-time">${trip.arrival_time}</div>
            <div class="trip-city">${trip.destination}</div>
          </div>
        </div>

        <div class="trip-meta">
          <span>★ ${Number(trip.operator_rating ?? trip.operatorRating ?? 4).toFixed(1)} rating</span>
          <span>${trip.amenities || 'No amenities listed'}</span>
        </div>
      </div>

      <div class="trip-side">
        <div>
          <div class="trip-price">₹${trip.currentPrice}</div>
          <div class="trip-price-note">${trip.occupancyPercent}% booked</div>
        </div>
        <div class="trip-seats">${trip.availableSeats} seats left</div>
        <button class="primary-btn" id="select-${trip.id}">Select seats</button>
      </div>
    </article>
  `;
}

// ---------- Seat selection ----------

async function openSeatModal(trip) {
  state.currentTrip = trip;
  state.selectedSeatIds = [];
  $('#seatModalTitle').textContent = `${trip.source} → ${trip.destination} · ${trip.departure_time}`;
  $('#seatMap').innerHTML = '<p class="empty-state">Loading seat map…</p>';
  $('#passengerForm').reset();
  updateFareSummary();
  $('#seatModal').showModal();

  try {
    const res = await fetch(`${API_BASE}/trips/${trip.id}/seats`);
    const data = await res.json();
    state.seats = data.seats;
    renderSeatMap();
  } catch (err) {
    $('#seatMap').innerHTML = '<p class="empty-state">Could not load seats.</p>';
  }
}

function renderSeatMap() {
  const decks = [...new Set(state.seats.map(s => s.deck))];
  const container = $('#seatMap');
  container.innerHTML = decks
    .map(deck => {
      const seatsInDeck = state.seats.filter(s => s.deck === deck);
      const seatButtons = seatsInDeck
        .map(seat => {
          const classes = ['seat-btn'];
          if (seat.is_booked) classes.push('booked');
          else if (state.selectedSeatIds.includes(seat.id)) classes.push('selected');
          else if (seat.recommended) classes.push('recommended');
          return `<button type="button" class="${classes.join(' ')}" data-seat-id="${seat.id}" ${seat.is_booked ? 'disabled' : ''}>${seat.seat_number}</button>`;
        })
        .join('');
      return `<div class="seat-deck"><h4>${deck} deck</h4><div class="seat-grid">${seatButtons}</div></div>`;
    })
    .join('');

  container.querySelectorAll('.seat-btn:not(.booked)').forEach(btn => {
    btn.addEventListener('click', () => toggleSeat(Number(btn.dataset.seatId)));
  });
}

function toggleSeat(seatId) {
  const idx = state.selectedSeatIds.indexOf(seatId);
  if (idx >= 0) state.selectedSeatIds.splice(idx, 1);
  else state.selectedSeatIds.push(seatId);
  renderSeatMap();
  updateFareSummary();
}

function updateFareSummary() {
  const count = state.selectedSeatIds.length;
  const price = state.currentTrip ? state.currentTrip.currentPrice : 0;
  $('#selectedSeatCount').textContent = count;
  $('#selectedFareTotal').textContent = `₹${count * price}`;
  $('#confirmBookingBtn').disabled = count === 0;
}

// ---------- Booking ----------

async function onConfirmBooking(e) {
  e.preventDefault();
  const payload = {
    tripId: state.currentTrip.id,
    seatIds: state.selectedSeatIds,
    passengerName: $('#passengerName').value.trim(),
    passengerAge: $('#passengerAge').value ? Number($('#passengerAge').value) : null,
    passengerGender: $('#passengerGender').value || null,
    phone: $('#passengerPhone').value.trim(),
    email: $('#passengerEmail').value.trim() || null,
  };

  const confirmBtn = $('#confirmBookingBtn');
  confirmBtn.disabled = true;
  confirmBtn.textContent = 'Booking…';

  try {
    const res = await fetch(`${API_BASE}/bookings`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json();

    if (!res.ok) {
      toast(data.error || 'Booking failed. Please try again.', 'error');
      confirmBtn.disabled = false;
      confirmBtn.textContent = 'Confirm booking';
      if (res.status === 409) openSeatModal(state.currentTrip); // refresh seat map
      return;
    }

    $('#seatModal').close();
    showTicket(data, payload);
    toast(`Booked! Your PNR is ${data.pnr}`);
  } catch (err) {
    toast('Could not reach the booking server.', 'error');
  } finally {
    confirmBtn.disabled = false;
    confirmBtn.textContent = 'Confirm booking';
  }
}

function showTicket(booking, passenger) {
  const trip = state.currentTrip;
  $('#ticketStub').innerHTML = `
    <div class="pnr">${booking.pnr}</div>
    <div class="divider"></div>
    <div class="ticket-row"><span>Passenger</span><strong>${passenger.passengerName}</strong></div>
    <div class="ticket-row"><span>Route</span><strong>${trip.source} → ${trip.destination}</strong></div>
    <div class="ticket-row"><span>Departure</span><strong>${trip.departure_time} · ${trip.travel_date}</strong></div>
    <div class="ticket-row"><span>Seats</span><strong>${booking.seatNumbers.join(', ')}</strong></div>
    <div class="ticket-row"><span>Bus</span><strong>${trip.operator_name} · ${trip.bus_type}</strong></div>
    <div class="divider"></div>
    <div class="ticket-row"><span>Total paid</span><strong>₹${booking.totalPrice}</strong></div>
  `;
  $('#ticketModal').showModal();
}

// ---------- My ticket lookup ----------

async function onLookupTicket() {
  const pnr = prompt('Enter your PNR / booking code:');
  if (!pnr) return;

  try {
    const res = await fetch(`${API_BASE}/bookings/${pnr.trim().toUpperCase()}`);
    const data = await res.json();
    if (!res.ok) {
      toast(data.error || 'Booking not found.', 'error');
      return;
    }
    $('#ticketStub').innerHTML = `
      <div class="pnr">${data.pnr}</div>
      <div class="divider"></div>
      <div class="ticket-row"><span>Passenger</span><strong>${data.passenger_name}</strong></div>
      <div class="ticket-row"><span>Route</span><strong>${data.trip.source} → ${data.trip.destination}</strong></div>
      <div class="ticket-row"><span>Departure</span><strong>${data.trip.departure_time} · ${data.trip.travel_date}</strong></div>
      <div class="ticket-row"><span>Seats</span><strong>${data.seatNumbers.join(', ')}</strong></div>
      <div class="ticket-row"><span>Status</span><strong>${data.status}</strong></div>
      <div class="divider"></div>
      <div class="ticket-row"><span>Total paid</span><strong>₹${data.price_paid}</strong></div>
    `;
    $('#ticketModal').showModal();
  } catch (err) {
    toast('Could not reach the booking server.', 'error');
  }
}
